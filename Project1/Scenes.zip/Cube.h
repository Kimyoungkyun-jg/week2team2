#pragma once
class Cube
{
};

